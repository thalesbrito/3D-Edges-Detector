%there will always be 2 points to represent a point shared by two different
%semantic objects. 3 if the point appear at an intersection of three
%differently labels objects, such as the corner of two walls and the
%ceilling. This functions aims to eliminate those multiple points.
function [gluedFaces] = glueFaces(faces, verticies)

    gluedFaces = faces; %creates a copy of the matrix faces

    for i = 1:size(verticies,1)
        [row1, col1] = findVector(verticies(i,:), verticies);
        if (size(row1,1)>1 && isempty(find(row1<i,1))) %find more than just itself and be the firt to be found (otherwise it has been already found)
            for j = 1:size(row1,1)
                %obj.v(row1(i),:) = [];  Cannot erase it, otherwise it will chante
                %the other line numbers. I'll just ignore the numbers.
                if ~(i == row1(j))
                    [row2, col2] = find(gluedFaces==row1(j));
                    for k = 1:size(row2,1)
                        gluedFaces(row2(k), col2(k)) = i;
                    end
                end
            end
        end
    end
end