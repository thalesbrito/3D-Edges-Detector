function [Labels, LabelsWeight, RowE, RowNE] = formatingDataOutput (edgePoints, numPoints)

    RowE = edgePoints;
    Labels = ones(numPoints, 1)*(-1);
    Labels(RowE) = 1;

    %same weight for now
    LabelsWeight = ones(numPoints,1);

    [RowNE] = find(Labels == (-1));
end
