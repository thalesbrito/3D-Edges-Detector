%labeling 3d cloud
function [labels, labelsWeight, rowE, rowNE] = edgeLabeling (scene, M, matrixEdgePhotos, edgeThreshold)

labelsProbab = zeros(size(M, 1), 2);
labels = zeros(size(M, 1), 1);
if scene == 1
    for aux1 = 1:size(M, 1)
        for aux2 = 1:M(aux1, 8)
            %if M(aux1, (8 + (aux2*4)-1)) == 220
            if M(aux1, (8 + (aux2*4)-1)) > 219 && M(aux1, (8 + (aux2*4)-1))<231 %check if it is related to the given scene
                %if matrixEdgePhotos{1,1}(M(aux1, 8 + (aux2*4)-2)+1, M(aux1, 8 + (aux2*4)-3)+1) == 1
                if matrixEdgePhotos{1,(M(aux1, (8 + (aux2*4)-1)) - 219)}(M(aux1, 8 + (aux2*4)-2)+1, M(aux1, 8 + (aux2*4)-3)+1) == 1
                    labelsProbab(aux1, 1) = 1;
                    labelsProbab(aux1, 2) =  labelsProbab(aux1, 2) + 1;
                end;
            end;
        end;
        %To avoid 'NaN' numbers
        if labelsProbab(aux1, 1) == 1
            labelsProbab(aux1, 2) = labelsProbab(aux1, 2)/M(aux1, 8);
        end;
    end;
end;

if scene == 2
    for aux1 = 1:size(M, 1)
        for aux2 = 1:M(aux1, 8)
            %if M(aux1, (8 + (aux2*4)-1)) == 220
            if M(aux1, (8 + (aux2*4)-1)) > 259 && M(aux1, (8 + (aux2*4)-1))<271
                %if matrixEdgePhotos{1,1}(M(aux1, 8 + (aux2*4)-2)+1, M(aux1, 8 + (aux2*4)-3)+1) == 1
                if matrixEdgePhotos{1,(M(aux1, (8 + (aux2*4)-1)) - 259)}(M(aux1, 8 + (aux2*4)-2)+1, M(aux1, 8 + (aux2*4)-3)+1) == 1
                    labelsProbab(aux1, 1) = 1;
                    labelsProbab(aux1, 2) =  labelsProbab(aux1, 2) + 1;
                end;
            end;
        end;
        %To avoid 'NaN' numbers
        if labelsProbab(aux1, 1) == 1
            labelsProbab(aux1, 2) = labelsProbab(aux1, 2)/M(aux1, 8);
        end;
    end;
end;

if scene == 3
    for aux1 = 1:size(M, 1)
        for aux2 = 1:M(aux1, 8)
            %if M(aux1, (8 + (aux2*4)-1)) == 220
            if M(aux1, (8 + (aux2*4)-1)) > 481 && M(aux1, (8 + (aux2*4)-1))<493
                %if matrixEdgePhotos{1,1}(M(aux1, 8 + (aux2*4)-2)+1, M(aux1, 8 + (aux2*4)-3)+1) == 1
                if matrixEdgePhotos{1,(M(aux1, (8 + (aux2*4)-1)) - 481)}(M(aux1, 8 + (aux2*4)-2)+1, M(aux1, 8 + (aux2*4)-3)+1) == 1
                    labelsProbab(aux1, 1) = 1;
                    labelsProbab(aux1, 2) =  labelsProbab(aux1, 2) + 1;
                end;
            end;
        end;
        %To avoid 'NaN' numbers
        if labelsProbab(aux1, 1) == 1
            labelsProbab(aux1, 2) = labelsProbab(aux1, 2)/M(aux1, 8);
        end;
    end;
end;


%labelProbab(:, 1) --> it's true if any of the evidences(images) tells that
%the point is an edge
%labelProbab(:, 2) --> probability given the number of evidences

%Find Indexes
[rowE, colE] = find(labelsProbab(:, 2)>edgeThreshold); %E to edges
[rowNE, colNE] = find(labelsProbab(:, 2)<=edgeThreshold); %NE to non-edges

%labelling accordingly to the edgeThreshold
labels(rowE) = 1;
labels(rowNE) = -1;

%weight for each observation - confidence of the labeling
labelsWeight = abs((labelsProbab(:, 2)-0.5))*2;
