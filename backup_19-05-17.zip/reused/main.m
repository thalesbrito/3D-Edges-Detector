%Thales Rodrigues de Brito - Engineering Research - ANU
%Main Function

%Parameters
%Neighbourhood definition
neighbSize = [0.01, 0.05, 0.1, 0.2, 0.4, 0.8, 1.6];%, 3.2];
rateDownSample = [0.1];                                    %p1 
method = 1;                                                %p2
threshold2D = 0.12% [0.04, 0.06, 0.08, 0.10, 0.12];              %p3
sigma = 0.5;                                               %p4
threshold3D = 0.5%[0.3, 0.4, 0.5, 0.6, 0.7];                   %p5

%-------------------------------------------------------------------------%
%OBTAINIG DATASET
%-------------------------------------------------------------------------%

scene = 1; %1, 2 or 3

%Readig .csv file
M = readPointClouds(scene);

%returns a M-by-1 structure filled with pics' informations    
matrixPanorPhotos = readPanorPicture(scene);

%Creating training and test point clouds


%-------------------------------------------------------------------------%
%DOWNSAMPLING
%-------------------------------------------------------------------------%
%OPTION 1
sizeTrainM = size(M(1:ceil(size(M,1)*0.7), :), 1);
trainM =       M(randperm( sizeTrainM, ceil(sizeTrainM*rateDownSample) ), :); %the 70% initial part of M  reduced and 10% downsamled
trainPoints =  M(randperm( sizeTrainM, ceil(sizeTrainM*rateDownSample) ), :); %points to be analysed for train
%86111 train points - 86111 points in trainM


testM = M(ceil(size(M,1)*0.7)+1:size(M,1), :);
sizeTestM = size(testM, 1);
aux = randperm(sizeTestM, ceil(sizeTestM*rateDownSample))';
testPoints =  testM(aux(:,1 ), :);  %indexes of points to be analysed for test
testM =       testM(aux(:,1 ), :); %the 30% final part of M  reduced and 10% downsamled
%36905 test points - 36905 points in testM

%OPTION 2
trainM = M(1:ceil(size(M,1)*0.7), :);
[trainLabels, trainLabelsWeight, trainRowE, trainRowNE] = generateTrainingData (scene, trainM, matrixPanorPhotos, 1, 0.06, 0.5, 0.4);
aux = randperm(size(trainRowNE, 1), 2*size(trainRowE, 1))';
trainPoints = [trainM(trainRowE,:); trainM(trainRowNE(aux), :)];
aux = randperm(size(trainM, 1),ceil(size(trainM, 1)*rateDownSample))';
trainM = trainM(aux, :);
%49272 train points - 86111 points in trainM

testM = M(ceil(size(M,1)*0.7)+1:size(M,1), :);
sizeTestM = size(testM, 1);
aux = randperm(sizeTestM, ceil(sizeTestM*rateDownSample))';
testPoints =  testM(aux(:,1 ), :);  %indexes of points to be analysed for test
testM =       testM(aux(:,1 ), :); %the 30% final part of M  reduced and 10% downsamled
%36905 test points - 36905 points in testM

%-------------------------------------------------------------------------%
%EDGE DETECTION
%-------------------------------------------------------------------------%

t1 = cputime;
performance = zeros(700, 16);
aux1 = 0;
for p1 = 1:size(rateDownSample,2)
    for p2 = 1:size(method,2)
        for p3 = 1:size(threshold2D,2)
            for p4 = 1:size(sigma,2)
                for p5 = 1:size(threshold3D,2)
                    
                    aux1 = aux1 + 1;

                    %-------------------------------------------------------------------------%
                    %GENERATING TRAINNING DATA
                    %-------------------------------------------------------------------------%

                    [trainLabels, trainLabelsWeight, trainRowE, trainRowNE] = generateTrainingData (scene, trainPoints, matrixPanorPhotos, method(p2), threshold2D(p3), sigma(p4), threshold3D(p5));
                    [testLabels, testLabelsWeight, testRowE, testRowNE] = generateTrainingData (scene, testPoints, matrixPanorPhotos, method(p2), threshold2D(p3), sigma(p4), threshold3D(p5));

                    %-------------------------------------------------------------------------%
                    %FEATURES EXTRACTION
                    %-------------------------------------------------------------------------%

                    %kd-tree model
                    kdModelTrain = KDTreeSearcher(trainM(:, 1:3), 'distance', 'euclidean');
                    kdModelTest = KDTreeSearcher(testM(:, 1:3), 'distance', 'euclidean');
                    
                    %Extracting features related to the covariance matrix of points within M
                    %for each defined scale
                    
                    
                    t = cputime;
                    trainFeaturesMatrix = covarFeaturesExtraction(trainM(:, 1:3), trainPoints(:, 1:3), neighbSize, kdModelTrain);
                    timeFeatTrain = cputime - t;

                    t = cputime;
                    testFeaturesMatrix = covarFeaturesExtraction(testM(:, 1:3), testPoints(:, 1:3), neighbSize, kdModelTest);
                    timeFeatTest = cputime - t;

                    %-------------------------------------------------------------------------%
                    %TRAINNING MODEL
                    %-------------------------------------------------------------------------%
                    
                    Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'method', 'AdaBoostM1', 'NumLearningCycles', 500, 'Learners', 'Tree');
                    
                    %Model chosen by 'OptimizeHyperparameters' - Whithout prior
                    t = cputime;
                    Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'method', 'Bag', 'NumLearningCycles', 448, 'Learners', templateTree('MinLeafSize',1), 'Resample', 'on', 'Weights', trainLabelsWeight);
                    modelTime = cputime - t;
                    
                    
                    t = cputime;
                    Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'method', 'Bag', 'NumLearningCycles', 23, 'Learners', templateTree('MinLeafSize',198), 'Resample', 'on', 'Weights', trainLabelsWeight);
                    modelTime = cputime - t;
%                     t = cputime;
%                     Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'method', 'Bag', 'NumLearningCycles', 448, 'Learners', templateTree('MinLeafSize',1), 'Resample', 'on', 'Weights', trainLabelsWeight(idxAnalysedPointsTrain));
%                     modelTime = cputime - t;

                    %-------------------------------------------------------------------------%
                    %CLASSIFIER
                    %-------------------------------------------------------------------------%
                    t = cputime;
                    testPredictedLabels = predict(Mdl,testFeaturesMatrix);
                    timePredTest = cputime - t;

                    t = cputime;
                    trainPredictedLabels = predict(Mdl,trainFeaturesMatrix);
                    timePredTrain = cputime - t;

                    %-------------------------------------------------------------------------%
                    %PERFORMANCE EVALUATION 
                    %-------------------------------------------------------------------------%
                    %test
                    [lossFuncTest, precisionTest, recallTest] = performanceEvaluation(testLabels, testPredictedLabels);

                    %trainning
                    [lossFuncTrain, precisionTrain, recallTrain] = performanceEvaluation(trainLabels, trainPredictedLabels);

                    %performance information
                    performance(aux1, :) = [rateDownSample(p1), method(p2), threshold2D(p3), sigma(p4), threshold3D(p5), precisionTrain, precisionTest, recallTrain, recallTest, lossFuncTrain, lossFuncTest, timeFeatTrain, timeFeatTest, modelTime, timePredTrain, timePredTest];
                    
                    %-------------------------------------------------------------------------%
                    %SAVE PERFORMANCE INFORMATION 
                    %-------------------------------------------------------------------------%
                    
                    save(sprintf('performance_%i.mat', aux1), 'performance');
                    display(aux1);
                    display(cputime-t1);
                end;
            end;
        end;
    end;
end;
                    
plotPerformance(scene, performance);

%-------------------------------------------------------------------------%
%OBSERVAIONS
%-------------------------------------------------------------------------%
% 1 - IMPROVE SET OF THRESHOLDS FROM 2D EDGE LABELLING
% 2 - CHECK FEATURE VALUES
% 3 - ADD MORE NEW FEATURES
% 4 - CHECK ENSEMBLE METHOD 
%edgeClassifier(edge2DDetector, sigma, gaussFilterSize, edge2DThreshold, edge3DThreshold, etc.  )
%check perfomance for trainning data set as well
 

%-------------------------------------------------------------------------%
%PRINTING TRAINNING DATA
%-------------------------------------------------------------------------%

%3D plot - Point cloud without edges
figure;
scatter3(M(:, 1), M(:, 2), M(:, 3), '.', 'y');
axis equal;

%2D plot - Images with edges
figure;
imshow(matrixEdgePhotos{1,1});

%3D plot - Edge printing
print3DCloud (M, [Labels]);


%-------------------------------------------------------------------------%
%TRAINNING MODEL
%-------------------------------------------------------------------------%

%Enssemble Learning
%try also LogitBoost

%Initial model
tic
Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'method', 'AdaBoostM1', 'NumLearningCycles', 100, 'Learners', templateTree('MaxNumSplits', 10, 'MinLeafSize', 34), 'LearnRate', 1, 'Weights', trainLabelsWeight(idxAnalysedPointsTrain), 'ClassNames', [1,-1], 'Prior', [0.0650, 0.9350]);
toc

%Finding Model using 'OptimizeHyperparameters'
 tic
 Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'ClassNames', [1,-1], 'Prior', [0.0650, 0.9350], 'OptimizeHyperparameters', 'auto');
 toc

%Model chosen by 'OptimizeHyperparameters'
% tic
% Mdl = fitcensemble(trainFeaturesMatrix, trainLabels, 'method', 'Bag', 'NumLearningCycles', 448, 'Learners', templateTree('MinLeafSize',1), 'Resample', 'on', 'Weights', trainLabelsWeight(idxAnalysedPointsTrain), 'ClassNames', [1,-1], 'Prior', [0.0650, 0.9350]);
% toc

% Determine the cumulative resubstitution losses (i.e., the cumulative misclassification error of the labels in the training data).
% rsLoss is a 100-by-1 vector, where element k contains the resubstition loss after the first k learning cycles.
% rsLoss = resubLoss(Mdl ,'Mode','Cumulative');
% 
% Plot the cumulative resubstitution loss over the number of learning cycles.
% figure;
% plot(rsLoss);
% xlabel('Number of Learning Cycles');
% ylabel('Resubstitution Loss');
