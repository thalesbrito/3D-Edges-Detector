function plotPerformance(scene, performance)

%plot loss-function x time training
[a, b] = max(sqrt(performance(1:512, 8).^2 + performance(1:512, 6).^2));
figure;
Xpr = performance(1:512, 8);
Ypr = performance(1:512, 6);
plot(Xpr,Ypr, 'b.');
hold on;
plot(performance(b, 8), performance(b, 6), 'r*');
xlabel('Recall'); ylabel('Precision');
title(sprintf('Scene %d - Precision-recall curve for training set', scene));
dim = [0.2 0.7 .1 .12];
if performance(b, 2) == 1
    printMethod = 'Sobel';
else
    printMethod = 'Canny';
end;
str = (sprintf('Best Performance: rateDownSample=%.2f, method=%s, threshold2D=%.2f, sigma=%.2f, threshold3D=%.2f', performance(b, 1), printMethod, performance(b, 3), performance(b, 4), performance(b, 5)));
annotation('textbox',dim,'String',str)
hold off;


%plot loss-function x time training
[a, b] = min(sqrt((performance(1:455, 12)+performance(1:455, 14)+performance(1:455, 15)).^2 + performance(1:455, 11).^2));
figure;
Xpr = performance(1:455, 12)+performance(1:455, 14)+performance(1:455, 15);
Ypr = performance(1:455, 11);
plot(Xpr,Ypr, 'b.');
hold on;
plot((performance(b, 12)+performance(b, 14)+performance(b, 15)), performance(b, 11), 'r*');
xlabel('Execution time'); ylabel('Loss-function');
title([sprintf('Scene %d - Loss-function x Execution time for training set',scene)]);
dim = [0.2 0.7 .1 .12];
if performance(b, 2) == 1
    printMethod = 'Sobel';
else
    printMethod = 'Canny';
end;
str = (sprintf('Best Performance: rateDownSample=%.2f, method=%s, threshold2D=%.2f, sigma=%.2f, threshold3D=%.2f', performance(b, 1), printMethod, performance(b, 3), performance(b, 4), performance(b, 5)));
annotation('textbox',dim,'String',str)
hold off;


%plot precision-recall curve
[a, b] = max(sqrt(performance(1:512, 9).^2 + performance(1:512, 7).^2));
figure;
Xpr = performance(1:512, 9);
Ypr = performance(1:512, 7);
plot(Xpr,Ypr, 'b.');
hold on;
plot(performance(b, 9), performance(b, 7), 'r*');
xlabel('Recall'); ylabel('Precision');
title([sprintf('Scene %d - Precision-recall curve for testing set', scene)]);
dim = [0.2 0.7 .1 .12];
if performance(b, 2) == 1
    printMethod = 'Sobel';
else
    printMethod = 'Canny';
end;
str = (sprintf('Best Performance: rateDownSample=%.2f, method=%s, threshold2D=%.2f, sigma=%.2f, threshold3D=%.2f', performance(b, 1), printMethod, performance(b, 3), performance(b, 4), performance(b, 5)));
annotation('textbox',dim,'String',str)
hold off;


%plot loss-function x time testing
[a, b] = min(sqrt((performance(1:512, 13)+performance(1:512, 14)+performance(1:512, 16)).^2 + performance(1:512, 10).^2));
figure;
Xpr = performance(1:512, 13)+performance(1:512, 14)+performance(1:512, 16);
Ypr = performance(1:512, 10);
plot(Xpr,Ypr, 'b.');
hold on;
plot((performance(b, 13)+performance(b, 14)+performance(b, 16)), performance(b, 10), 'r*');
xlabel('Execution time'); ylabel('Loss-function');
title([sprintf('Scene %d - Loss-function x Execution time for testing set', scene)]);
dim = [0.2 0.7 .1 .12];
if performance(b, 2) == 1
    printMethod = 'Sobel';
else
    printMethod = 'Canny';
end;
str = (sprintf('Best Performance: rateDownSample=%.2f, method=%s, threshold2D=%.2f, sigma=%.2f, threshold3D=%.2f', performance(b, 1), printMethod, performance(b, 3), performance(b, 4), performance(b, 5)));
annotation('textbox',dim,'String',str)
hold off;


%plot precision-recall curve test - 10% downsampled
figure;
Xpr = performance(performance(1:200, 5)>=0.4, 9);
Ypr = performance(performance(1:200, 5)>=0.4, 7);
plot(Xpr,Ypr, 'b.');
hold on;

Xpr = performance(performance(1:200, 5)<0.4, 9);
Ypr = performance(performance(1:200, 5)<0.4, 7);
plot(Xpr,Ypr, 'g.');


%plot precision-recall curve test - 20% downsampled
Xpr = performance(performance(201:400, 5)>=0.5, 8);
Ypr = performance(performance(201:400, 5)>=0.5, 6);
plot(Xpr,Ypr, 'r.');


Xpr = performance(performance(201:400, 5)<0.5, 8);
Ypr = performance(performance(201:400, 5)<0.5, 6);
plot(Xpr,Ypr, 'y.');


Xpr = performance(performance(1:200, 5)==0.5, 8);
Ypr = performance(performance(1:200, 5)==0.5, 6);
plot(Xpr,Ypr, 'g.');
hold on;










%plot precision-recall curve training

%varying sigma
for aux1 = 1:5
    a = [performance(60+aux1, 8) performance(160+aux1, 8) performance(260+aux1, 8);
    performance(65+aux1, 8) performance(165+aux1, 8) performance(265+aux1, 8);
    performance(70+aux1, 8) performance(170+aux1, 8) performance(270+aux1, 8);
    performance(75+aux1, 8) performance(175+aux1, 8) performance(275+aux1, 8)];

    b = [performance(60+aux1, 6) performance(160+aux1, 6) performance(260+aux1, 6);
    performance(65+aux1, 6) performance(165+aux1, 6) performance(265+aux1, 6);
    performance(70+aux1, 6) performance(170+aux1, 6) performance(270+aux1, 6);
    performance(75+aux1, 6) performance(175+aux1, 6) performance(275+aux1, 6)];


    % Figure Defaults
    figure;
    set(0,'DefaultTextFontSize',10);
    set(0,'DefaultAxesFontSize',10);
    set(0,'defaultAxesFontName', 'Times New Roman');
    set(0,'defaultTextFontName', 'Times New Roman');
    set(0,'defaultAxesColorOrder',[0 0 0]);
    set(0,'defaultAxesLineStyleOrder','-|--|:|-.');
    plot(a, b);
    xlabel('Recall'); ylabel('Precision');
    title(sprintf('Scene %d - Precision-recall curve varying parameter sigma', scene));
end;

hold on;










