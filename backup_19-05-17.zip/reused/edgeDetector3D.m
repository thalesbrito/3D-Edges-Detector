function [performance] = edgeDetector3D (scene, M, matrixPanorPhotos, rateDownSample, method, threshold2D, sigma, threshold3D)



%-------------------------------------------------------------------------%
%GENERATING TRAINNING DATA
%-------------------------------------------------------------------------%

[trainLabels, trainLabelsWeight] = generateTrainingData (scene, trainM, matrixPanorPhotos, rateDownSample, method, threshold2D, sigma, threshold3D);
[testLabels, testLabelsWeight] = generateTrainingData (scene, testM, matrixPanorPhotos, rateDownSample, method, threshold2D, sigma, threshold3D);

%-------------------------------------------------------------------------%
%FEATURES EXTRACTION
%-------------------------------------------------------------------------%

%Neighbourhood definition
neighbSize = [0.01, 0.05, 0.1, 0.2, 0.4, 0.8, 1.6];%, 3.2];


%Extracting features related to the covariance matrix of points within M
%for each defined scale
t = cputime;
trainFeaturesMatrix = covarFeaturesExtraction(M(:, 1:3), idxDownSampledMTrain, idxAnalysedPointsTrain, neighbSize);
timeFeatTrain = cputime - t;

t = cputime;
testFeaturesMatrix = covarFeaturesExtraction(M(:, 1:3), idxDownSampledMTest, idxAnalysedPointsTest, neighbSize);
timeFeatTest = cputime - t;

%-------------------------------------------------------------------------%
%TRAINNING MODEL
%-------------------------------------------------------------------------%

%Model chosen by 'OptimizeHyperparameters' - Whithout prior
t = cputime;
Mdl = fitcensemble(trainFeaturesMatrix, trainLabels(idxAnalysedPointsTrain), 'method', 'Bag', 'NumLearningCycles', 448, 'Learners', templateTree('MinLeafSize',1), 'Resample', 'on', 'Weights', trainLabelsWeight(idxAnalysedPointsTrain));
modelTime = cputime - t;


%-------------------------------------------------------------------------%
%CLASSIFIER
%-------------------------------------------------------------------------%
t = cputime;
testPredictedLabels = predict(Mdl,testFeaturesMatrix);
timePredTest = cputime - t;

t = cputime;
trainPredictedLabels = predict(Mdl,trainFeaturesMatrix);
timePredTrain = cputime - t;

%-------------------------------------------------------------------------%
%PERFORMANCE EVALUATION 
%-------------------------------------------------------------------------%
%test
[lossFuncTest, precisionTest, recallTest] = performanceEvaluation(testLabels, idxAnalysedPointsTest, testPredictedLabels);

%trainning
[lossFuncTrain, precisionTrain, recallTrain] = performanceEvaluation(trainLabels, idxAnalysedPointsTrain, trainPredictedLabels);

%performance information
performance = [rateDownSample, method, threshold2D, sigma, threshold3D, precisionTrain, precisionTest, recallTrain, recallTest, lossFuncTrain, lossFuncTest, timeFeatTrain, timeFeatTest, modelTime, timePredTrain, timePredTest];

