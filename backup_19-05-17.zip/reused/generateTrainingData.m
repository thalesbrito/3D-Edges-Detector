function [Labels, LabelsWeight, RowE, RowNE] = generateTrainingData (scene, M, matrixPanorPhotos, method, threshold2D, sigma, threshold3D)

%Function Parameters: 
%M - point cloud to be labelled
%matrixPanorPhotos - matrix containing the photos
%method - 'sobel' or 'canny'
%threshold2D - To choose the 2D edges
%sigma  - Related to the gaussina distribution;
%threshold3D - To be used during projection decision


if method == 1
    %2D Edge detection - Sobel
    %threshold = 'auto'; %'auto' when automatic
    %sigma = 1; %Default: 0.5
    matrixEdgePhotos = sobelEdgeDetector(matrixPanorPhotos, threshold2D, sigma);
else
    if method == 2
    %2D Edge detection - Canny without non-maximum supression 
    %sigma = 0.5;
    %threshold = 0.04; %Needs to be greater than 1
    matrixEdgePhotos = sobelEdgeDetector(matrixPanorPhotos, threshold2D, sigma);
    else
        disp('Method not available!');
    end;
end;

%Labeling 3D point cloud - Edges and non-edges
[Labels, LabelsWeight, RowE, RowNE] = edgeLabeling (scene, M, matrixEdgePhotos, threshold3D);

