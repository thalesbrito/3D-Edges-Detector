%Thales Rodrigues de Brito - Engineering Research - ANU
%Extracting features related to the covariance matrix of points within M

%-------------------------------------------------------------------------%
%FEATURES IDENTIFICATION
%-------------------------------------------------------------------------%
%f1 = Sum
%f2 = Omnivariance
%f3 = Eigenentropy
%f4 = Anisotropy
%f5 = Planarity
%f6 = Linearity
%f7 = Surface Variation
%f8 = Sphericity
%f9 = Verticallity
%-------------------------------------------------------------------------%

function [featuresMatrix] = covarFeaturesExtraction(downSampledM, analysedPoints, neighbSize, kdModel)

%M --> the rows are the points and the columns their position [x, y, z]


%Matrix to store the feature vector for each point for each defined scale
%rows: points
%columns: different neighbourhoods
featuresMatrix = zeros(size(analysedPoints, 1), length(neighbSize)*9); %9 is the number of features


%Gets the indexes and distances of the points whithin defined neighbourhood
for aux1 = 1:length(neighbSize)
    display('Neigbourhood Size');
    display(neighbSize(aux1));
    featLastPos = aux1*9-9;
    actualNeighbSize = neighbSize(aux1);
    %Find points within a spheric region of the pre-defined radius
    Idx = rangesearch(kdModel, analysedPoints, actualNeighbSize);


    %checks max # of neighbours -> to prealocate H
    max = 0;
    for i = 1:size(analysedPoints, 1)
        if length(Idx{i})>max
            max = length(Idx{i});
        end;
    end;
    H = zeros(max+1, 3);

    %covariance Matrix Calculation - Considers the actual point as the centroid    
    for aux2 = 1:size(analysedPoints, 1)
        numberNeighb = length(Idx{aux2});
        
        if numberNeighb>3
            %idxDownSampledM(Idx(aux2, :)) --> contain the indexes in M of
            %the neinghbours
            centroidX = (sum(downSampledM(Idx{aux2, :}, 1)) + analysedPoints(aux2, 1))/(numberNeighb+1); %calculating centroid
            %display(centroidX);
            centroidY = (sum(downSampledM(Idx{aux2, :}, 2)) + analysedPoints(aux2, 2))/(numberNeighb+1);
            %display(centroidY);
            centroidZ = (sum(downSampledM(Idx{aux2, :}, 3)) + analysedPoints(aux2, 3))/(numberNeighb+1);
            %display(centroidZ);
            
            for aux3 = 1:(numberNeighb) 
                    %display('calc');
                    %display((M(currentNeighb, 1)));
                    H(aux3,1) = sqrt((downSampledM(Idx{aux2}(aux3), 1) - centroidX)^2); %Should I calculate th euclidean distance?
                    H(aux3,2) = sqrt((downSampledM(Idx{aux2}(aux3), 2) - centroidY)^2); %Did I misunderstood the meaning of centroid?
                    H(aux3,3) = sqrt((downSampledM(Idx{aux2}(aux3), 3) - centroidZ)^2);
                    %should I include the actual point?
            end;
            
            if downSampledM(Idx{aux2}(1), :) ~= analysedPoints(aux2, :)
                H(aux3+1,1) = sqrt((analysedPoints(aux2, 1) - centroidX)^2); %Should I calculate th euclidean distance?
           	    H(aux3+1,2) = sqrt((analysedPoints(aux2, 2) - centroidY)^2); %Did I misunderstood the meaning of centroid?
                H(aux3+1,3) = sqrt((analysedPoints(aux2, 3) - centroidZ)^2);    
                covarMatrix = (H(1:numberNeighb+1, :)'*H(1:numberNeighb+1, :))/(numberNeighb+1);
            else
                covarMatrix = (H(1:numberNeighb, :)'*H(1:numberNeighb, :))/(numberNeighb);
            end;
            
            %display(aux2);
            %display(H(1:numberNeighb, :));
            %display('covMatrix');
            %display(covarMatrix);
        
            %Obtaining biggest eigenvalues and eigenvectors
            [eVectors, eValues] = eigs(covarMatrix);
            %eValues(3,3)>eValues(2,2)eValues(1,1)>=0
            

            
            %display('eValues');
            %display(eValues);
            %Defining each feature and Filling the multiscale feature matrix

            %Checking for negative zeros
            if eValues(1, 1) <= 0
                if eValues(2, 2) <= 0
                    if eValues(3, 3) <= 0
                        %%All the eigenvalues are zero or negative
                        featuresMatrix(aux2, featLastPos+1:featLastPos+8) = [0 0 0 0 0 0 0 0];
                        featuresMatrix(aux2, featLastPos+9) = 1 - abs(eVectors(1, 1));
                    else
                        %First and Second eigenvalues are zero or negative
                    	featuresMatrix(aux2, featLastPos+1) = eValues(1,1)+eValues(2,2)+eValues(3,3);
                        featuresMatrix(aux2, featLastPos+2) = 0;
                        featuresMatrix(aux2, featLastPos+3) = 0 +0 +(eValues(3,3)*log(eValues(3,3)));
                        featuresMatrix(aux2, featLastPos+4) = (eValues(3,3)-eValues(1,1))/eValues(3,3); 
                        featuresMatrix(aux2, featLastPos+5) = (eValues(2,2)-eValues(1,1))/eValues(3,3);
                        featuresMatrix(aux2, featLastPos+6) = (eValues(3,3)-eValues(2,2))/eValues(3,3);
                        featuresMatrix(aux2, featLastPos+7) = eValues(1,1)/featuresMatrix(aux2, featLastPos+1);
                        featuresMatrix(aux2, featLastPos+8) = eValues(1,1)/eValues(3,3);
                        featuresMatrix(aux2, featLastPos+9) = 1 - abs(eVectors(1, 1));
                    end;
                else
                    %Just the smaller eigenvalue is zero or negative
                    featuresMatrix(aux2, featLastPos+1) = eValues(1,1)+eValues(2,2)+eValues(3,3);
                    featuresMatrix(aux2, featLastPos+2) = 0;
                    featuresMatrix(aux2, featLastPos+3) = 0 +(eValues(2,2)*log(eValues(2,2)))+(eValues(3,3)*log(eValues(3,3)));
                    featuresMatrix(aux2, featLastPos+4) = (eValues(3,3)-eValues(1,1))/eValues(3,3); 
                    featuresMatrix(aux2, featLastPos+5) = (eValues(2,2)-eValues(1,1))/eValues(3,3);
                    featuresMatrix(aux2, featLastPos+6) = (eValues(3,3)-eValues(2,2))/eValues(3,3);
                    featuresMatrix(aux2, featLastPos+7) = eValues(1,1)/featuresMatrix(aux2, featLastPos+1);
                    featuresMatrix(aux2, featLastPos+8) = eValues(1,1)/eValues(3,3);
                    featuresMatrix(aux2, featLastPos+9) = 1 - abs(eVectors(1, 1)); 
                end;
            else
                %none of the eigenvalues are zero or negative
            	featuresMatrix(aux2, featLastPos+1) = eValues(1,1)+eValues(2,2)+eValues(3,3);
                featuresMatrix(aux2, featLastPos+2) = (eValues(1,1)*eValues(2,2)*eValues(3,3))^(1/3);
                featuresMatrix(aux2, featLastPos+3) = (eValues(1,1)*log(eValues(1,1)))+(eValues(2,2)*log(eValues(2,2)))+(eValues(3,3)*log(eValues(3,3)));   
                featuresMatrix(aux2, featLastPos+4) = (eValues(3,3)-eValues(1,1))/eValues(3,3); 
                featuresMatrix(aux2, featLastPos+5) = (eValues(2,2)-eValues(1,1))/eValues(3,3);
                featuresMatrix(aux2, featLastPos+6) = (eValues(3,3)-eValues(2,2))/eValues(3,3);
                featuresMatrix(aux2, featLastPos+7) = eValues(1,1)/featuresMatrix(aux2, featLastPos+1);
                featuresMatrix(aux2, featLastPos+8) = eValues(1,1)/eValues(3,3);
                featuresMatrix(aux2, featLastPos+9) = 1 - abs(eVectors(1, 1));
            end;
        else
            featuresMatrix(aux2, featLastPos+1:featLastPos+9) = [0 0 0 0 0 0 0 0 0];
        end;  
    end;
end;



